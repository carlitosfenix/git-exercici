let valorSelected = "";
let cantidadesHtml;
let salidaHTML;



function crearPronts() {

    let numero = cantidadesHtml.value;
    let Anombre = [];
    let Aedad = [];
    let Atitulo = [];
    let Aparo = [];
    let Abecados = [];


    for (i = 0; i < numero; i++) {
        Anombre.push(prompt("Entra el Nombre del  alumNo: " + i));
        Aedad.push(parseInt(prompt("Entra la edad Nombre del  alumNo: " + i)));
        Atitulo.push(prompt("Entra si tiene titulo el  alumNo (no = no): " + i));
        Aparo.push(prompt("Entra si está en pàro el  alumNo (no = no): " + i));
        if ((Aedad[i] >= 18 && Atitulo !== "no") || Aparo[i] !== "no") {
            Abecados.push(Anombre[i]);
        }

    }

    mostrarSalida(Abecados);


}

function mostrarSalida(elArray) {
    elArray.sort();
    salidaHTML.innerHTML = elArray;
    console.log(elArray);
}

function inicio() {
    cantidadesHtml = document.getElementById("inpCantidad");
    salidaHTML = document.getElementById("salida");

}