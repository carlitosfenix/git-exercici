var valorSelected = "";
var cantidadesHtml;


function crearPronts() {

    var numero = cantidadesHtml.value;
    var miArray = [];


    for (i = 1; i <= numero; i++) {
        palabra = prompt("Entra la palabra n: " + i);
        miArray.push(palabra);
    }

    mostrarSalida(miArray);


}

function mostrarSalida(elArray) {
    elArray.sort();
    var salidaHTML = document.getElementById("salida");
    salidaHTML.innerHTML = elArray[0];
    console.log(elArray[0]);
}

function inicio() {
    cantidadesHtml = document.getElementById("inpCantidad");
}